package com.jogamp.opengl.test.junit.graph.demos;

import com.jogamp.graph.curve.Region;

public class GPUUISceneGLListener02 extends GPUUISceneGLListener0A {
    public GPUUISceneGLListener02() {
        super(Region.VBAA_RENDERING_BIT);
    }
}
